﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;

//This Assignment requires the use of OO Program
//Split into 5 sections
//The pattern used in this is the Abstract Factory Design Pattern
//For the creation of the SVG file we use Microsoft Edge


namespace assignment_05
{
    //Section 1: This will be the main class in which we will make the a few commands for the console application
    public class Program
    {
        public static void Main(String[] args)
        {
            Console.WriteLine("Welcone to the application, press -H for help");
            createInterface();
        }

        public static void createInterface()
        {
            Stack<String> printCanvas = new Stack<String>();
            Stack<String> undoCanvas = new Stack<String>();

            //While loop 
            while(true)
            {
                String userInput = Console.ReadLine();
                String[] split = userInput.Split(' ');
                String undo = "";
                String redo = " ";
                String shape = "";

                //A switch statement will be used to show a list of commands
                switch(split[0].ToUpper())
                {
                    case "H":
                    Console.WriteLine("These are the following commands please type them");
                    Console.WriteLine("H : Redirects you to a list of commands");
                    Console.WriteLine("A : allows you to add a shape to the SVG file (i.e A circle)");
                    Console.WriteLine("U : allows you to undo the last shape added to the SVG file");
                    Console.WriteLine("R : allows you to redo the shape added to the SVG file");
                    Console.WriteLine("P: prints out the shapes that is listed in the SVG file");
                    Console.WriteLine("C: Clear the canvas");
                    Console.WriteLine("S: Saves and Downloads the SVG file");
                    Console.WriteLine("Q: Quit the application");
                    break;

                    case "A":
                    Console.WriteLine("We have created the following shape: " + split[1]);
                    shape = new Client().addShape(split[1]);
                    printCanvas.Push(shape);
                    break;

                    //This will undo the Shape
                    case "U":
                    Console.WriteLine("We have undoed the shape");
                    if(printCanvas.Count() != 0)
                    {
                        String a = printCanvas.Pop();
                        undoCanvas.Push(a);
                    }

                    else
                    {
                        Console.WriteLine("We cannot undo the shape as there is nothing to undo!");
                    }
                    break;

                    case "R":
                    Console.WriteLine("We have redoed the shape: ");

                    if(undoCanvas.Count > 0)
                    {
                        redo = undoCanvas.Pop();
                        printCanvas.Push(redo);
                    }

                    else
                    {
                        Console.WriteLine("We cannot redo the shape as there is nothing to redo!");
                    }
                    break;

                    //This will print the shape
                    case "P":

                    //For this work we need to use the a foreach loop
                    foreach(String listofshapes in printCanvas)
                    {
                        Console.WriteLine(listofshapes);
                    }

                    break;

                    //This will be used to print the Shapes
                    case "S":
                    saveFile(printCanvas);
                    break;

                    case "Q":
                    Console.WriteLine("Thank you come again!");
                    Environment.Exit(1);
                    break;

                    default:
                    Console.WriteLine("This is not an appropiate command, please try again");
                    break;
                }
            }   
        }

        public static void saveFile(Stack<string> save)
        {
            //This will be used as the file to save the SVG File
            string file = @"..\Assignment-05\svgundoredo.svg"; //Creates the SVG File (N.B: ensure that there is an .\)
            List<string> list = new List<string>(); //This will create the svg file

            //We will make a template for the SVG File
            list.Add("<svg version='1.1' xmlns = 'http://www.w3.org/2000/svg' height= '1000' width= '1000'> \n"); //This creates the boiler plate

            foreach(String s in save)
            {
                list.Add(s);
            }
            list.Add("</svg>"); //End of SVG File

            //Now we can make a file out it using the following:
            System.IO.File.WriteAllLines(file,list);
            Console.WriteLine("We have produced an SVG File!");           
        }
    }

    //Section 2: We can use it to create a bunch of shapes using classes

    //Creates the circle class    
    class Circle : Shape
    {   
        //Let's create a few variables for this to work
        Random rand = new Random(); //Allows us to randomize points
        public String[] colors = {"blue","orange","red","purple","yellow","pink"}; //Randomize a list of colors


        //Create getters and setters
        public int xAxis
        {
            get;
            set;
        } 

        public int yAxis
        {
            get;
            set;
        }

        public int radius
        {
            get;
            set;
        }

        public String fill
        {
            get;
            set;
        }

        public String stroke
        {
            get;
            set;
        }


       public string create()
       {
           //Randomize the points of the x,y,radius
           xAxis = rand.Next(1,100);
           yAxis = rand.Next(1,100);
           radius = rand.Next(1,100);
           stroke = colors[rand.Next(0,colors.Length-1)];
           fill = colors[rand.Next(0,colors.Length-1)];

            //Return the method
            return "<circle cx='" +xAxis +"' cy='" +yAxis +"' r='" +radius  +"' fill= '" +fill +"' stroke= '"+stroke +"' />";

       }
    }

    class Ellipse : Shape
    {   
        //Let's create a few variables for this to work
        Random rand = new Random(); //Allows us to randomize points
        public String[] colors = {"blue","orange","red","purple","yellow","pink"}; //Randomize a list of colors


        //Create getters and setters
        public int xCAxis
        {
            get;
            set;
        } 

        public int yCAxis
        {
            get;
            set;
        }

        public int xRadius
        {
            get;
            set;
        }

        public int yRadius
        {
            get;
            set;
        }

          public String fill
        {
            get;
            set;
        }

        public String stroke
        {
            get;
            set;
        }

       public string create()
       {
           //Randomize the points of the x,y,radius
           xCAxis = rand.Next(1,100);
           yCAxis = rand.Next(1,100);
           xRadius = rand.Next(1,100);
           yRadius = rand.Next(1,100);
           stroke = colors[rand.Next(0,colors.Length-1)];
           fill = colors[rand.Next(0,colors.Length-1)];

            //Return the method
            return "<ellipse cx='" +xCAxis +"' cy='" +yCAxis +"' rx='" +xRadius +"' ry='" +yRadius +"' fill= '" +fill +"' stroke= '"+stroke + "' />";
       }
    }

    //Creates the Rectangle class
    class Rectangle : Shape
    {   
        //Let's create a few variables for this to work
        Random rand = new Random(); //Allows us to randomize points
        public String[] colors = {"blue","orange","red","purple","yellow","pink"}; //Randomize a list of colors


        //Create getters and setters
        public int xAxis
        {
            get;
            set;
        } 

        public int yAxis
        {
            get;
            set;
        }

        public int width
        {
            get;
            set;
        }

        public int height
        {
            get;
            set;
        }

        public String fill
        {
            get;
            set;
        }

        public String stroke
        {
            get;
            set;
        }

       public string create()
       {
           //Randomize the points of the x,y,width and height
           xAxis = rand.Next(1,100);
           yAxis = rand.Next(1,100);
           width = rand.Next(1,100);
           height = rand.Next(1,100);
           stroke = colors[rand.Next(0,colors.Length-1)];
           fill = colors[rand.Next(0,colors.Length-1)];

            //Return the method
            return "<rect x= '" + xAxis +"' y= '" + yAxis +"' width= '" + width +"' height= '" +height + "' fill= '" +fill +"' stroke= '"+stroke +"' />";
       }
    }

    //Now we use it to create a Line
      class Line : Shape
    {   
        //Let's create a few variables for this to work
        Random rand = new Random(); //Allows us to randomize points
        public String[] colors = {"blue","orange","red","purple","yellow","pink"}; //Randomize a list of colors


        //Create getters and setters
        public int xOne
        {
            get;
            set;
        } 

        public int yOne
        {
            get;
            set;
        }

        public int xTwo
        {
            get;
            set;
        }

        public int yTwo
        {
            get;
            set;
        }

        public String fill
        {
            get;
            set;
        }

        public String stroke
        {
            get;
            set;
        }

       public string create()
       {
           //Randomize the points of the x,y,radius
           xOne = rand.Next(1,100);
           yOne = rand.Next(1,100);
           xTwo = rand.Next(1,100);
           yTwo = rand.Next(1,100);
           stroke = colors[rand.Next(0,colors.Length-1)];
           fill = colors[rand.Next(0,colors.Length-1)];

            //Return the method
            return "<line x1= '" +xOne +"' y1= '" +yOne +"' x2= '" +xTwo +"' y2= '" +yTwo + "' fill= '" +fill +"' stroke= '"+stroke + "' />";
       }
    }

    class Polyline : Shape
    {
        Random rand = new Random();
        public String[] colors = {"blue","orange","red","purple","yellow","pink"}; //Randomize a list of colors

        public String fill
        {
            get;
            set;
        }

        public String stroke
        {
            get;
            set;
        }

        public string create()
        {
            String poly = "";
            int x = rand.Next(2,10);
            if(x % 2 != 0)
            {
                x++;
            }
            int [] ar = new int[x];
            poly = "<polyline points = '";
            
            for(int i = 0; i < x; i++)
            {
                ar[i] = rand.Next(1,1000); 

            }

            for(int i = 0; i < x; i++)
            {
                if(i % 2 == 0)
                {
                    poly += ar[i] +",";
                }
                else
                {
                    poly += ar[i] +" ";
                }

            }
          stroke = colors[rand.Next(0,colors.Length-1)];
           fill = colors[rand.Next(0,colors.Length-1)];
            
            return poly + "' fill= '" +fill +"' stroke= '"+stroke + "' />";
        }
    }

    class Polygon : Shape
    {
        Random rand = new Random();
        public String fill
        {
            get;
            set;
        }

        public String stroke
        {
            get;
            set;
        }
        public String[] colors = {"blue","orange","red","purple","yellow","pink"}; //Randomize a list of colors

        public string create()
        {
            String polygon = "";
            int x = rand.Next(2,10);
            if(x % 2 != 0)
            {
                x++;
            }
            int [] ar = new int[x];
            polygon = "<polygon points = '";
            
            for(int i = 0; i < x; i++)
            {
                ar[i] = rand.Next(1,1000); 

            }

            for(int i = 0; i < x; i++)
            {
                if(i % 2 == 0)
                {
                    polygon += ar[i] +",";
                }
                else
                {
                    polygon += ar[i] +" ";
                }

            }

            stroke = colors[rand.Next(0,colors.Length-1)];
           fill = colors[rand.Next(0,colors.Length-1)];
            
            return polygon + "' fill= '" +fill +"' stroke= '"+stroke + "' />";
        }
    }

    class Path : Shape
    {
        Random rand = new Random();
        public String fill
        {
            get;
            set;
        }

        public String stroke
        {
            get;
            set;
        }
        public String[] colors = {"blue","orange","red","purple","yellow","pink"}; //Randomize a list of colors

        String path = "";

        public string create()
        {
            path = "<path  d='M 100 350 q 150 -300 300 0" ;
            stroke = colors[rand.Next(0,colors.Length-1)];
           fill = colors[rand.Next(0,colors.Length-1)];
            return path + "' fill= '" +fill +"' stroke= '"+stroke + "' />";
        }
    }

    //Section 3: Create a bunch of abstract classes to create a bunch Factory class for the creation of the shape
     public interface Shape         //Contains general structure of the subclasses, in this instance Operation() Returns a string containing the Shapes SVG Code
    {
        public String create();
    }
        
    abstract class createShape
    {
        public abstract Shape AbstractFactory();

        //Creates a method which declares the shape
        public string makeShape()
        {
            var makeShape = AbstractFactory();
            var finalShape = makeShape.create();
            return finalShape; 
        }
    }

        //Now using this data we can create a class and it will return the class type interface
        class CircleAbstract : createShape
        {
            public override Shape AbstractFactory()
            {
                return new Circle();
            }
        }

        //Creates the Rectangle
        class RectangleAbstract : createShape
        {
            public override Shape AbstractFactory()
            {
                return new Rectangle();
            }
        }

        //Create the Ellipse
        class EllipseAbstract : createShape
        {
            public override Shape AbstractFactory()
            {
                return new Ellipse();
            }
        }

         class LineAbstract : createShape
        {
            public override Shape AbstractFactory()
            {
                return new Line();
            }
        }

        //Creates the Polyline
        class PolylineAbstract : createShape
        {
            public override Shape AbstractFactory()
            {
                return new Polyline();
            }
        }

        //Creates the polyline
        class PolygonAbstract : createShape
        {
            public override Shape AbstractFactory()
            {
                return new Polygon();
            }
        }

          class PathAbstract : createShape
        {
            public override Shape AbstractFactory()
            {
                return new Path();
            }
        }
    
    

    //Section 4: Using this data we can create a client for the Shapes
    class Client
    {
        public String Code(createShape user)
        {
            Console.WriteLine("We will create the shape");
            return user.makeShape();
        }

        //To make sure that the client makes adds the shape a switch statement will suffice it
        public String addShape(string shape)
        {
            String callShape = "";

            switch(shape.ToLower())
            {
                case "circle":
                callShape = Code(new CircleAbstract());
                return callShape;

                case "ellipse":
                callShape = Code(new EllipseAbstract());
                return callShape;

                case "rectangle":
                callShape = Code(new RectangleAbstract());
                return callShape;

                case "line":
                callShape = Code(new LineAbstract());
                return callShape;

                case "polygon":
                callShape = Code(new PolygonAbstract());
                return callShape;

                case "polyline":
                callShape = Code(new PolylineAbstract());
                return callShape;

                case "path":
                callShape = Code(new PathAbstract());
                return callShape;

                default:
                Console.WriteLine("Not an appropiate shape please write again");
                return null;
            }
        }
    }
}


