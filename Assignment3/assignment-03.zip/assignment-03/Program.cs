﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace assignment_03
{
    //This code will be split into a few sections which will require the usage of getters and setters and the usage of shapes

    //Let's first create a bunch of variables needed for most parts of the shapes
    //Section 1: We will first create a class for the creation of shapes.
    public class Shapes
    {
        public int xAxis
        {
            get;
            set;
        }

          public int xxAxis
        {
            get;
            set;
        }

        public int yAxis
        {
            get;
            set;
        }

        public int yyAxis
        {
            get;
            set;
        }

        public string stroke
        {
            get;
            set;
        }

        public string fill
        {
            get;
            set;
        }
    }

    //Now using the template above we can create the desired that we want
    public class Rectangle : Shapes
    {
        /**
        *Using the following reference from assignment-02 and this will be used to create an svg file of a rectangle
        *Reference: https://developer.mozilla.org/en-US/docs/Web/SVG/Element/rect
        *So using that we can create getters and setters for the shape itself
        **/

        public int width
        {
            get;
            set;
        }

        public int height
        {
            get;
            set;
        }

        public int rx
        {
            get;
            set;
        }


        public int ry
        {
            get;
            set;
        }


        public Rectangle(int x, int y, int h, int w)
        {
            xAxis = x;
            yAxis = y;
            height = h;
            width = w;
        }

        public string makeShape()
        {
            return " <rect x= '" + xAxis + "' y='" + yAxis + "' height='" + height + "' width='" + width + "' />";
        }
    }

     public class Circle : Shapes
    {
        /**
        *Using the following reference from assignment-02 and this will be used to create an svg file of a rectangle
        *Reference: https://developer.mozilla.org/en-US/docs/Web/SVG/Element/circle
        *So using that we can create getters and setters for the shape itself
        **/

        public int centreX
        {
            get;
            set;
        }

        public int centreY
        {
            get;
            set;
        }

        public int radius
        {
            get;
            set;
        }

        public Circle(int x, int y, int r)
        {
            xAxis = x;
            yAxis = y;
            radius = r;
        }

        public string makeShape()
        {
            return " <circle cx='" + xAxis + "' cy='" + yAxis + "' r='" + radius + "' />";
        }
    }

    public class Line : Shapes
    {
        //For the production of the line it only requires the production of the connext of 2 x axis' and 2 y-axis' which we have already created
        public Line(int x, int x2, int y, int y2, string s)
        {
            xAxis = x;
            yAxis = y;
            xxAxis = x2;
            yyAxis = y2;
            stroke = s;
        }

        public string makeShape()
        {
            return "<line x1='" + xAxis + "' y1='" + yAxis +  "' x2='" + xxAxis +  "' y2='" + yyAxis +  "' stroke='" + stroke  + "' />";
        }
    }

    public class Ellipse : Shapes
    {
        //We will use the getters we made in shapes as a template to the creation of the ellipse
        //xxAxis will be the rx and yyAxis will be ry

        public Ellipse(int cx, int cy, int rx, int ry, string f)
        {
            xAxis = cx;
            yAxis = cy;
            xxAxis = rx;
            yyAxis = ry;
            fill = f;
        }

        public string makeShape()
        {
            return "<ellipse cx='" + xAxis +  "' cy='" + yAxis + "' rx='" + xxAxis + "' ry='" + yyAxis  + "' />";
        }
    }

    public class Polyline : Shapes
    {
        public string points
        {
            get;
            set;
        }

        //So for this to work we just need a string to plot the points
        public Polyline(string p,string s, string f)
        {
            points = p;
            stroke = s;
            fill = f;
        }

        public string makeShape()
        {
            return "<polyline points='" +  points + "' fill='" + fill +  "' stroke='" + stroke + "' />";
        }

    }

     public class Polygon : Shapes
    {
        //We will work the same way as we did for the polyline
        public string points
        {
            get;
            set;
        }

        public Polygon(string p,string s, string f)
        {
            points = p;
            stroke = s;
            fill = f;
        }

        public string makeShape()
        {
            return "<polygon points='" +  points + "' fill='" + fill +  "' stroke='" + stroke + "' />";
        }
    }

    public class Paths : Shapes
    {
        //We will work the same way as we did for both the polygon and the polyline
        public string points
        {
            get;
            set;
        }

        public Paths(string p, string f)
        {
            points = p;
            fill = f;
        }

        public string makeShape()
        {
            return "<path d='" + points +  "' fill='" + fill + "' />";
        }
    }

    //This is for the extra marks section we will add Text
    public class Text:Shapes
    {
        public string txt
        {
            get;
            set;
        }  

        public string font
        {
            get;
            set;
        }    

        public Text(int x, int y, string f, string text)
        {
            xAxis = x;
            yAxis = y;
            font = f;
            txt = text;
        }

        public string makeShape()
        {
            return "<text x='" + xAxis + "' y='" + yAxis + "' style='" + "font-family:"+  font +";'" +  ">" +  txt + "</text>"; 
        }
    }

    //For extra marks we will replicate everything above but using specific parameters but we typically only need one and thats the triangle.
    public class specificRectangle : Shapes
    {
        /**
        *Using the following reference from assignment-02 and this will be used to create an svg file of a rectangle
        *Reference: https://developer.mozilla.org/en-US/docs/Web/SVG/Element/rect
        *So using that we can create getters and setters for the shape itself
        **/

        public int width
        {
            get;
            set;
        }

        public int height
        {
            get;
            set;
        }

        public int rx
        {
            get;
            set;
        }


        public int ry
        {
            get;
            set;
        }

        public specificRectangle(int x, int y, int h, int w, int rxAxis, int ryAxis)
        {
            xAxis = x;
            yAxis = y;
            height = h;
            width = w;
            rx =rxAxis;
            ry =ryAxis;
        }

        public string makeShape()
        {
            return " <rect x= '" + xAxis + "' y='" + yAxis + "' height='" + height + "' width='" + width +  "' rx='" + rx + "' ry='" + ry + "' />";
        }
    }
    
     
    
    
    //Now that we have created the Shapes necessary for the the creation of this console app we can use it to create the commands for the app
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello! Welcome to the SVG generator app, please press -H to choose the following commands");
            
            addCommand c = new addCommand();
            List<string> canvasList = new List<string>();
            List<string> deletedList = new List<string>();


            while(true)
            {
                string hi = Console.ReadLine();
                string [] inputParts = hi.Split(' ');

                switch(inputParts[0])
                {
                case "H":
                //For this step to work you need to create a bunch of console.WriteLines
                Console.WriteLine("These are some the commands which you can choose from");
                Console.WriteLine("H:- list of the following commands you can use");
                Console.WriteLine("A: allows the user to add the shape of your choice (e.g. A circle");
                Console.WriteLine("U: allows you to undo the shape you recently created");
                Console.WriteLine("R: allow you to redo the shape you recently undid");
                Console.WriteLine("S: Allows you to save the shape into an SVG File");
                Console.WriteLine("Q: allows you to quit the application");
                Console.WriteLine("D: allows you to display the SVG's you have recently added");
                
                Console.WriteLine("");
                break;

                case "A":
                addShape(hi,canvasList);
                break;

                case "U":
                c.undo(canvasList,deletedList);
                break;

                case "R":
                c.redo(canvasList,deletedList);
                break;

                case "C":
                c.clear(canvasList,deletedList);
                break;

                case "S":
                c.saveList(canvasList);
                break;

                case "P":
                c.printList(canvasList);
                break;

                case "Q":
                Console.WriteLine("Thank you! We hope to see you soon");
                Environment.Exit(1);
                break;

                default: 
                Console.WriteLine("This is not an appropiate command, please try again"); 
                break;
                }
            }
        }

        public static void addShape(string shape, List<string> canvasList)
        {
            //So for the creation of the shape all we need to do is to create a substring in this case it will start at index 2
            string input = shape.Substring(2);
            Random rand = new Random();
            string points = "";
            int RandomPoints = rand.Next(0,10);
            int x = 0;
            int y = 0;
            int height = 0;
            int width = 0;
            int rx = 0;
            int ry = 0;
        
            //Now using this switch statement we can create add a few shapes.
            switch(input)
            {
                case "rectangle":
                Console.WriteLine("Would you like to create parameter for a specific triangle? Type Y or N");
                string user = Console.ReadLine();
                user = user.ToUpper();

                while(!user.Equals("Y") || !user.Equals("N"))
                {                    
                    if(user == "Y")
                    {
                    Console.WriteLine("Print x:");
                    x = int.Parse(Console.ReadLine());
                    Console.WriteLine("Print y:");
                    y = int.Parse(Console.ReadLine());
                    Console.WriteLine("Print height:");
                    height = int.Parse(Console.ReadLine());
                    Console.WriteLine("Print width:");
                    width = int.Parse(Console.ReadLine());   
                    Console.WriteLine("Print rx:");
                    rx = int.Parse(Console.ReadLine());   
                    Console.WriteLine("Print rx:");
                    ry = int.Parse(Console.ReadLine());  
                    specificRectangle rec = new specificRectangle(x,y,height,width,rx,ry);
                    canvasList.Add(rec.makeShape());
                    break;
                    }

                    else if(user == "N")
                    {
                    Console.WriteLine("Print x:");
                    x = int.Parse(Console.ReadLine());
                    Console.WriteLine("Print y:");
                    y = int.Parse(Console.ReadLine());
                    Console.WriteLine("Print height:");
                    height = int.Parse(Console.ReadLine());
                    Console.WriteLine("Print width:");
                    width = int.Parse(Console.ReadLine());
                    Rectangle rec = new Rectangle(x,y,height,width);
                    canvasList.Add(rec.makeShape());
                    break;
                    }

                    else
                    {
                        Console.WriteLine("Please type Y or N");
                        user = Console.ReadLine();
                        user = user.ToUpper();
                    }
                }
                
                break;

                case "circle":
                Console.WriteLine("Print x:");
                int x1 = int.Parse(Console.ReadLine());
                Console.WriteLine("Print y:");
                int y1 = int.Parse(Console.ReadLine());
                Console.WriteLine("Print radius:");
                int radius = int.Parse(Console.ReadLine());
        
                
                Circle circ = new Circle(x1,y1,radius);
                canvasList.Add(circ.makeShape());
                break;

                case "ellipse":
                Console.WriteLine("Print cx:");
                int cx = int.Parse(Console.ReadLine());
                Console.WriteLine("Print cy:");
                int cy = int.Parse(Console.ReadLine());
                Console.WriteLine("Print rx:");
                 rx = int.Parse(Console.ReadLine());
                Console.WriteLine("Print ry:");
                 ry = int.Parse(Console.ReadLine());

                Ellipse ellipse = new Ellipse(cx,cy,rx,ry,"blue");
                canvasList.Add(ellipse.makeShape());
                break;

                case "line":
                Console.WriteLine("Print x1:");
                int lx1 = int.Parse(Console.ReadLine());
                Console.WriteLine("Print x2:");
                int lx2 = int.Parse(Console.ReadLine());
                Console.WriteLine("Print y1:");
                int ly1 = int.Parse(Console.ReadLine());
                Console.WriteLine("Print y2:");
                int ly2 = int.Parse(Console.ReadLine());

                Line line = new Line(lx1,lx2,ly1,ly2,"black");
                canvasList.Add(line.makeShape());
                break;

                case "path":
                Paths path = new Paths("M 10,30 A 20,20 0,0,1 50,30 A 20,20 0,0,1 90,30 Q 90,60 50,90 Q 10,60 10,30 z", "pink");
                canvasList.Add(path.makeShape());
                break;

                case "polygon":

                for(int i = 0; i < RandomPoints; i++)
                {
                    points += rand.Next(0,500) + ",";
                }
                Polygon polygon = new Polygon(points, "blue", "black");
                canvasList.Add(polygon.makeShape());
                break;
                
                case "polyline":
                points = "";
                for(int i = 0; i < RandomPoints; i++)
                {
                    points += rand.Next(0,500) + ",";
                }
                Polyline polyline = new Polyline(points, "blue", "black");
                canvasList.Add(polyline.makeShape());
                break;

                case "text":
                Console.WriteLine("Print x1:");
                int tx = int.Parse(Console.ReadLine());
                Console.WriteLine("Print x2:");
                int ty = int.Parse(Console.ReadLine());
                Console.WriteLine("Choose the type of Font");
                string font = Console.ReadLine();
                Console.WriteLine("Choose the text:");
                string  txt = Console.ReadLine();
                Text text = new Text(tx,ty,font,txt);
                canvasList.Add(text.makeShape());
                break;
                

                case "default":
                Console.WriteLine("This shape " + input + " does not exist, please choose another shape");
                break;
            }
        }
    }

    /**3. So for the production of this application we will be using the Command pattern for Undoing and Redoing the pattern    
    *We already have parts set up but we need to create a couple of more parts
    **/

        public class addCommand{
         //Set up a few variables needed for this add to work
        public static List<string> canvasList = new List<string>();
    	public static List<string> deletedElements = new List<string>();

        
        public void printList(List<string> getList)
        {
            getList.ForEach(Console.WriteLine);
        }

        public void undo(List<string> getList, List<string> deletedList)
        {
            deletedList.Add(getList[getList.Count-1]);
            getList.RemoveAt(getList.Count-1);
            getList.ForEach(Console.WriteLine);
        }

        public void redo(List<string> getList, List<string> deletedList)
        {
            getList.Add(deletedList[0]);
            deletedList.RemoveAt(deletedList.Count-1);
            canvasList.ForEach(Console.WriteLine);
            deletedList.ForEach(Console.WriteLine);
        }

        public void saveList(List<string> getList)
        {
            string file = @"C:\Users\ryano\Desktop\assignment-03\assignment03.svg";
            List<string> svgFile = new List<string>();
            List<string> newList = getList;
            svgFile.Add("<svg version='1.1' xmlns = 'http://www.w3.org/2000/svg' height= '1000' width= '1000'>");
            svgFile.AddRange(newList.ToList());
            svgFile.Add("</svg>");
            System.IO.File.WriteAllLines(file,svgFile);
        }

        public void clear(List<string> getList, List<string> deletedElement)
        {
            getList.Clear();
            deletedElement.Clear();
            Console.WriteLine("We have cleared the canvas");
            getList.ForEach(Console.WriteLine);
        }
    }

    
}
