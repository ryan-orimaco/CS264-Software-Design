﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Assignment_04
{
    /*Some requistes before starting:
            -We will use the Command Pattern Method for the Undo-Redo
            -There will some brand new references that will be required for the production of shapes
            -We will make Class Diagram with this.
            -Will write an 200-500 word essay about my approach to Assignment-03 and Assignment-04.
            -Split the parts into a couple of sections
    */


    //Section 1: The first section will focus on the creation of Shapes.
    public class Shapes
    {
        //We will create the necessary parameters needed for shapes by the use of getters and setters

        //This one will be for the x-Axis.
        public int xAxis
        {
            get;
            set;
        }

        //This one will be for the Y-Axis.
        public int yAxis
        {
            get;
            set;
        }

        //This one will be for the x2-Axis. (Needed for the production of a line)
        public int x2Axis
        {
            get;
            set;
        }

        //This will be the y2 Axis. (Needed for the line)
        public int y2Axis
        {
            get;
            set;
        }

        //This will be needed for a radius
        public int radius
        {
            get;
            set;
        }

        //This will be used for to fill a color for the shape (Aside: This is a string not an int)
        public string fillColor
        {
            get;
            set;
        }

        //This will be used for stroke color for a shape (Aside: This is also a string not an int)
        public string strokeColor
        {
            get;
            set;
        }
    }

    //Section 2: Because we created a class for these Shapes we can used these as a template to create the shapes that were needed
    public class Rectangle : Shapes
    {
        //We dont need to create any getters or setters here as we already them above. However we need to create a getter and setters for height and width
        //Reference: https://developer.mozilla.org/en-US/docs/Web/SVG/Element/rect
        public int height{
            get;
            set;
        }

        public int width
        {
            get;
            set;
        }
        public Rectangle(int x, int y, int w, int h, string stroke)
        {
            xAxis = x;
            yAxis = y;
            width = w;
            height = h;
            strokeColor = stroke;
        }

        //We will return the string
        public override string ToString()
        {
            return " <rect x= '" + xAxis + "' y='" + yAxis + "' height='" + height + "' width='" + width + "' />";
        }
    } 

    public class Circle : Shapes
    {
        //We dont need to create any getters or setters here as we already them above. However we need to create a getter and setters for height and width
        //Reference: https://developer.mozilla.org/en-US/docs/Web/SVG/Element/circle

         //This one will be for the x-Axis.
        public int xCircle
        {
            get;
            set;
        }

        //This one will be for the Y-Axis.
        public int yCircle
        {
            get;
            set;
        }

        public int radiusCircle{
            get;
            set;
        }
    
        public Circle(int cx, int cy, int r)
        {
            cx = xCircle;
            cy = yCircle;
            r = radiusCircle;
        }

        //We will return the string
        public override string ToString()
        {
            return " <circle cx='" + xCircle + "' cy='" + yCircle + "' r='" + radiusCircle + "' />";
        }
    } 

    public class Ellipse : Shapes
    {
        //For the ellipse we will use xAxis, x2Axis, yAxis, y2Axis getters and setters to create the ellipse
        public Ellipse(int cx, int cy, int rx, int ry)
        {
            xAxis = cx;
            yAxis = cy;
            x2Axis = rx;
            y2Axis = ry;
        }

        //We will return a string
        public override string ToString()
        {
            return "<ellipse cx= '" + xAxis + "' cy= '" + yAxis + "' rx= '" + x2Axis + "' ry= '" + y2Axis + "' />";
        }
    }

    public class Line : Shapes
    {
        //We will use the same steps as the Ellipse class to create the Line Shape
        public Line(int x1, int y1, int x2, int y2)
        {
            xAxis = x1;
            yAxis = y1;
            x2Axis = x2;
            y2Axis = y2;
        }

       public override string ToString()
       {
           return "<line x1= '" + xAxis + "' y1= " + yAxis + "' x2= " + x2Axis + "' y2= " + y2Axis + "' />";
       }
    }

    //Now we will use this to create a Path.
    //For Reference: https://developer.mozilla.org/en-US/docs/Web/SVG/Element/path
    public class Path : Shapes
    {
        //This will be complete diffrent as we will need to use a string to create a Path
        public string points
        {
            get;
            set;
        }

        public Path(string p)
        {
            points = p;
        }

        public override string ToString()
        {
            return "<path d= '" + points + "' />";
        }
    }

    //Next creation will be a the creation of a Polygon this will completely diffrent. As instead of one integer, this will multiple integers that will plotted.
    //Reference: https://developer.mozilla.org/en-US/docs/Web/SVG/Element/polygon
    public class Polygon : Shapes
    {
        public List<int> points
        {
            get;
            set;
        }

        public Polygon(List<int> p)
        {
            points  = p;
        }

        public override string ToString()
        {
            //We are going to use a complete diffrent approach to this because we will needed to produce many different points
            string points = "<polygon points = '";
            int count = 0;

            //The issue here is what happens when reach the end of the randomly generated points(We will randomly generate points)
            //For this to work we will for loops with an if-else statements (if even then we add a comma else we finish)
            foreach(int item in points)
            {
                points += item; //Adds the necessary randomly generated points into word

                //Now this is important because we will loop it as statement above
                if(count % 2 == 0)
                {
                     points += ",";
                }

                else
                {
                    points += " ";
                }
                count++; //We increment and go to the next part
            }
            points += " ' />";
            return points;
        }
    }

    //We will use the exact same step for the creation of a polyline
    //Reference: https://developer.mozilla.org/en-US/docs/Web/SVG/Element/polyline
    public class Polyline : Shapes
    {
        public List<int> points
        {
            get;
            set;
        }

        public Polyline(List<int> p)
        {
            points = p;
        }

        public override string ToString()
        {
            //We are going to use a complete diffrent approach to this because we will needed to produce many different points
            string points = "<polyline points = '";
            int count = 0;

            //The issue here is what happens when reach the end of the randomly generated points(We will randomly generate points)
            //For this to work we will for loops with an if-else statements (if even then we add a comma else we finish)
            foreach(int item in points)
            {
                points += item; //Adds the necessary randomly generated points into word

                //Now this is important because we will loop it as statement above
                if(count % 2 == 0)
                {
                     points += ",";
                }

                else
                {
                    points += " ";
                }
                count++; //We increment and go to the next part
            }
            points += " ' />";
            return points;
        }
    }
    //End of Section 2.


    //Section 3: This is the main program itself where we create the basic parts for creating the console application
    public class Program
    {
        public static void Main(String[] args)
        {
            //Let's bring the necessary classes here
            Shapes shapes= new Shapes();
            Canvas canvas = new Canvas();
            User user = new User();
            interfaceCreation(canvas,user);

        }

        //Interface Creation method is needed for this
        public static void interfaceCreation(Canvas canvas, User user)
        {
            
             Console.WriteLine("Hey friend, welcome! Before beginning please type 'H' to find out the commands");
            
            //This while loop will be used to print the list of the following commands that are needed.
            while(true)
            {
                string input = Console.ReadLine();
                
                //So for the following commands to work the we need to use a switch statement.
                switch(input.Split(' ')[0])
                {
                    case "H":
                    Console.WriteLine("These are the following commands please type them");
                    Console.WriteLine("H : Redirects you to a list of commands");
                    Console.WriteLine("A : allows you to add a shape to the SVG file (i.e A circle)");
                    Console.WriteLine("U : allows you to undo the last shape added to the SVG file");
                    Console.WriteLine("R : allows you to redo the shape added to the SVG file");
                    Console.WriteLine("P: prints out the shapes that is listed in the SVG file");
                    Console.WriteLine("C: Clear the canvas");
                    Console.WriteLine("S: Saves and Downloads the SVG file");
                    Console.WriteLine("Q: Quit the application");
                    break;

                    case "A":
                    Console.WriteLine("This is the result from the following command: ");
                    addShape(input,canvas,user);
                    break;

                    case "U":
                    user.undoShape();
                    break;

                    case "R":
                    user.redoShape();
                    break;

                    case "P":
                    Console.WriteLine(canvas);
                    break;

                    case "S":
                    saveFile(canvas);
                    break;

                    case "C":
                    canvas.canvasClear();
                    break;

                    case "Q":
                    Console.WriteLine("Thank you come again!");
                    Environment.Exit(1);
                    break;

                    default:
                    Console.WriteLine("This is not an appropiate command, please try again");
                    break;

                }
            }
        }


        //Work on the other commands after Section 4
        //Now using these commands we can create the commands from below that was used in the Command Pattern
        //We will first use this to create add Shape into the canvas
        public static void addShape(string input, Canvas c, User u)
        {
            /**To add the shape we need the following
            *1. Split the input string so we can only the shapes needed
            *2. Make a switch statement and add the shapes
            */

            string shape = input.Substring(2);
            Console.WriteLine(shape);
            Random rand = new Random();

            
            switch(shape.ToLower())
            {
                //We will make a bunch of cases
                //We will use it to make a rectangle
                case "rectangle":
                Console.WriteLine("We have added the shape: " + shape);   
                u.createAction(new addCommand(new Rectangle(rand.Next(1, 1000), rand.Next(1, 1000), rand.Next(1, 1000), rand.Next(1, 1000), "red"), c));             
                break;

                //Now we will use it make a ellipse
                case "ellipse":
                Console.WriteLine("We have added the shape: " + shape);   
                u.createAction(new addCommand(new Ellipse(rand.Next(1,100), rand.Next(1,100), rand.Next(1,100), rand.Next(1,100)),c));
                break;

                //Now we will use it to make a line
                case "line":
                Console.WriteLine("We have added the shape: " + shape);   
                u.createAction(new addCommand(new Line(rand.Next(1,100), rand.Next(1,100), rand.Next(1,100), rand.Next(1,100)),c));
                break;

                //Now we can use it to create a circle
                case "circle":
                Console.WriteLine("We have added the shape: " + shape);   
                u.createAction(new addCommand(new Circle(rand.Next(1,100),rand.Next(1,100),rand.Next(1,1000)),c));
                break;

                //We can then use it to create a Path
                case "path":
                Console.WriteLine("We have added the shape: " + shape);
                List<int> pathPoint = randomPoints();
                string combinedString = String.Join(",", pathPoint);
                u.createAction(new addCommand(new Path(combinedString),c));
                break;

                //Work on the creation of a polyline and polygon later
                //Before starting this we need to create a method which creates a bunch of random points
                case "polygon":
                Console.WriteLine("We have added the shape: " + shape);   
                List<int> polygonPoint = randomPoints();
                u.createAction(new addCommand(new Polygon(polygonPoint),c));
                break;

                case "polyline":
                Console.WriteLine("We have added the shape: " + shape);   
                List<int> polylinePoint = new List<int>();
                polylinePoint = randomPoints();
                u.createAction(new addCommand(new Polyline(polylinePoint),c));
                break;

                default:
                Console.WriteLine("This is not an appropiate command, please try again");
                break;
            }
            
        }


        //To create a bunch of random points we will need to randomize a bunch of points
        public static List<int> randomPoints()
        {
            Random rnd = new Random();
            List<int> list = new List<int>();
            int y = rnd.Next(2,12);
            
            if(y % 2 == 1)
            {
                y--;
            }

            for(int i = 0; i < y; i++)
            {
                list.Add(rnd.Next(1,500));
            }
            return list;
        }

        //We will now create more commands for this application to work
        //This time the creation of a print list will be used
        public static void printCanvas(List<string> list)
        {
            Console.WriteLine("Here are the follwing shapes written in the canvas so far: ");
            list.ForEach(Console.WriteLine);
        }

        //Last simple command that can be created is the production of a file for SVG Download use
        public static void saveFile(Canvas canvas)
        {
            string file = @"..\Assignment-04\svgundoredo.svg"; //Creates the SVG File (N.B: ensure that there is an .\)
            List<string> list = new List<string>(); //This will create the svg file

            //We will make a template for the SVG File
            list.Add("<svg version='1.1' xmlns = 'http://www.w3.org/2000/svg' height= '1000' width= '1000'> \n"); //This creates the boiler plate
            list.Add(canvas.ToString()); //Adds all the added shapes into the SVG File
            list.Add("</svg>"); //End of SVG File

            //Now we can make a file out it using the following:
            System.IO.File.WriteAllLines(file,list);
            Console.WriteLine("We have produced an SVG File!");            

        }
    }
    //End of Section 3

    
    //Section 4: We will now use the Command Pattern Method for this app to work but for the sake of the we will use a Canvas
    public class Canvas
    {
        private Stack<Shapes> canvas = new Stack<Shapes>();

        //This section will we create a canvas to allow us to add and remove shapes of our choice. A canvas is also needed to save the SVG
        //Let's put some getters and setters as we needed it to 
        public int x_Axis
        {
            get;
            set;
        }

        public int y_Axis
        {
            get;
            set;
        }

        public Canvas()
        {
            Console.WriteLine("We have created a new Canvas");
        }

        //This will be used to add the shape into an application above
        public void addShape(Shapes s)
        {
            canvas.Push(s);
            Console.WriteLine("We have added the shape " + s);
        }

        //Now we also need a command to delete the shape
        public Shapes undoShape()
        {
            Shapes delete = canvas.Pop();
            Console.WriteLine("We have undoed the shape ");
            return delete;
        }
        
        //We also need a feature which will clear the canvas this will be easy as there is already a clear feature 
        public void canvasClear()
        {
            canvas.Clear();
        }

        //Now using the ToString commands we created in Shapes we need it to so we can print them out in the canvas
        public override string ToString()
        {
            string shape = "";

            foreach(Shapes s in canvas)
            {
                shape += s + "\r\n";
            }

            return shape;
        }
    }
    //End of Section 4

    //Section 5: This section is where some of our commands will be used in Section
    public abstract class Command
    {
        public abstract void redo();
        public abstract void undo();
    }

    //The add command will be used to create a shape into the canvas by creating a new class
    public class addCommand : Command
    {
        Shapes s; //Bring the Shapes class here
        Canvas c; //Bring the canvas class here

        //This will do this in the addShape section
        public addCommand(Shapes shapes, Canvas canvas)
        {
            s = shapes;
            c = canvas;
        }

        public override void redo()
        {
            c.addShape(s);
        }

        public override void undo()
        {
            s = c.undoShape();
        }
    }

    public class deleteCommand : Command
    {
        Shapes shape;
        Canvas canvas;

        public deleteCommand(Canvas c)
        {
            canvas = c;
        } 

        public override void redo()
        {
            shape = canvas.undoShape();
        }

        public override void undo()
        {
            canvas.addShape(shape);
        }
    }
    //End of Section 5

    //Section 6: This section is a user section which is needed for the Command Pattern
    public class User
    {
        //For this whole section to work we need to create private stacks
        private Stack<Command> undo; //This is the list to undo the list.
        private Stack<Command> redo; //This is the list to redo the command

        //Then we use these stacks to create a new getter to count the number of undo's that occured
        public int undoCount
        {
            get => undo.Count();
        }

        //We do the exact same thing for a redo getter
        public int redoCount
        {
            get => redo.Count();
        }

        //Then we use this to 
        public User()
        {
            reset();
            Console.WriteLine("New User has been created");
            Console.WriteLine();
        }

        public void reset()
        {
            undo = new Stack<Command>();
            redo = new Stack<Command>();
        }

        public void createAction(Command command)
        {
            undo.Push(command);
            redo.Clear();
            Type type = command.GetType();

            if(type.Equals(typeof(addCommand)))
            {
                Console.WriteLine("We have added the new shape");
                command.redo();
            }

            if(type.Equals(typeof(deleteCommand)))
            {
                Console.WriteLine("We have deleted the shape");
                command.redo();
            }
        }

        public void undoShape()
        {
            Console.WriteLine("Let's undo the last shape");
            Console.WriteLine();
            
            if(undo.Count > 0)
            {
                Command com = undo.Pop();
                com.undo();
                redo.Push(com);
            }
        }

        public void redoShape()
        {
            Console.WriteLine("Let's redo the last shape");
            Console.WriteLine();

            if(redo.Count > 0)
            {
                Command com = redo.Pop();
                com.redo();
                undo.Push(com);
            }
        }
    }
    //End of Section 6 and the last section
    
}